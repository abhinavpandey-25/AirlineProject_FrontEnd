export class Passengers
{
    bookingId:number=0;
    name:String = "";
    passengerAge:number = 0;
    gender:String ="";
    seatNo:String = "";
}