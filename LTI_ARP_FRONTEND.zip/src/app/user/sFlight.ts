export class sFlight{

    source: string="";
    destination: string="";
    departureDate: string="";
    travelClass: string="";
    noOfPassengers:number =0;

    // constructor() {
    //     this.departureDate = new Date().toISOString().slice(0, 16);
        
    // }
}