export class Payment {
    transactionId: number = 0;
    bookingId: number = 0;
    cardHolderName: String = "";
    cardNumber: number = 0;
    totalCost: number = 0;
    expiry: string="";
    cvv: number=0;
}