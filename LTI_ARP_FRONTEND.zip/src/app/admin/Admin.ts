export class Admin{

    adminId: number=0;
    email: string="";
    password: string="";
}