export class User
{
    userId:number=0;
    title:String = "";
    email:String = "";
    password:String ="";
    firstName:String = "";
    LastName:String = "";
    phoneNumber:number =0;
}