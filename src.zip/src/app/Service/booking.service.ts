import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http:HttpClient) { }

  public searchFlight1(source:string, destination:string, departureDate:string, travelClass:string)  {
    
    return this.http.post("http://localhost:8090/api/v1/" ,{ source, destination, departureDate, travelClass});
  }

}
